<?php

namespace app\modules\v1\controllers;

use sizeg\jwt\Jwt;
use sizeg\jwt\JwtHttpBearerAuth;
use Yii;
use app\components\Controller;
use app\components\JwtCreator;
use app\modules\v1\models\Product;
use app\modules\v1\models\search\ProductsSearch;

class HomeController extends RestController
{
    public function actionIndex()
    {
        // $my_array_of_parameters = ['product_name,product_image'];
        $search['ProductsSearch'] = Yii::$app->request->queryParams;
        $searchModel  = new ProductsSearch();
        // $searchModel->attributes = $my_array_of_parameters; // likely $_POST['something']
        $dataProvider = $searchModel->search($search);

        return $this->apiCollection([
            'count'      => $dataProvider->count,
            'dataModels' => $dataProvider->models,
        ], $dataProvider->totalCount);
    }
}
